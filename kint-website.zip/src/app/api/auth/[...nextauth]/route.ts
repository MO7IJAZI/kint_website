import { handlers } from "@/auth";

console.log("Handlers check:", handlers);

export const { GET, POST } = handlers;
