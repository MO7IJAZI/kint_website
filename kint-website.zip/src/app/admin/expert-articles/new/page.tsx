import ExpertArticleForm from "@/components/admin/ExpertArticleForm";

export default function NewExpertArticlePage() {
    return (
        <div>
            <h1 style={{ fontSize: '2rem', marginBottom: '2rem' }}>New Expert Article</h1>
            <ExpertArticleForm />
        </div>
    );
}
